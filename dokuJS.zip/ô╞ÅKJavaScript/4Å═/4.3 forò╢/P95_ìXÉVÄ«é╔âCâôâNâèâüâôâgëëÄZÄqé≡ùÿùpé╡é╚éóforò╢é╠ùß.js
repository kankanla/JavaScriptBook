for (var i = 0; i < 20; i += 3) {
  document.write(i, '<br/>');
}
