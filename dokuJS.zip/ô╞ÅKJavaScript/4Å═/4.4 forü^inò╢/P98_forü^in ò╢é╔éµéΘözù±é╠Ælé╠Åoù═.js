var season = ['Spring', 'Summer', 'Fall', 'Winter'];
for (var prop in season) {
  document.write(season[prop], '<br/>');
}
