try {
  document.write(x);
} catch(e) {
  alert(e);
}
