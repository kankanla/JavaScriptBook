function sample(arg0) {
  alert(arguments[1]);
}
sample(1, 'arguments');
