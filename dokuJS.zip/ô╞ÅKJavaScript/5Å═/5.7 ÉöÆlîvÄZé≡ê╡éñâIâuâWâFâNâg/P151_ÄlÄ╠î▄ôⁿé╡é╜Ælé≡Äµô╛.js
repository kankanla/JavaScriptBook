var r = Math.round(123.45);
alert(r);
