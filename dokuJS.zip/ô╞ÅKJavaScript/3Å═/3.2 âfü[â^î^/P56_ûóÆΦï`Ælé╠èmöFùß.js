var x;
alert(x);
