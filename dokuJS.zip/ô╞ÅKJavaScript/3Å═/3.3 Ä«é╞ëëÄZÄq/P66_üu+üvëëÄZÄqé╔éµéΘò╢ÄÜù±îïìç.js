var result1 = 'Hello' + 'World';
var result2 = '1' + '2';
var result3 = '1' + 2;
var result4 = 1 + 2;
alert(result1 + '\n' + result2 + '\n' + result3 + '\n' + result4);
