var obj = {prop1 : '1' , prop2 : '2' , prop3 : '3'};
with (obj) {
  alert(prop2);
}
