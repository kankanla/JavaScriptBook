alert(Object.prototype.__proto__);
