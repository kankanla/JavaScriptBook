document.write('<hr>');
document.write('Hello world!');
document.write('<hr>');