var num = 0;
var result1 = typeof num;
var str = '������';
var result2 = typeof str;
var flg = true;
var result3 = typeof flg;
var func = function() { return 0; };
var result4 = typeof func;
var ary = [ 1, 2, 3 ];
var result5 = typeof ary;
var x;
var result6 = typeof x;
alert(result1 + '\n' + result2 + '\n' + result3 + '\n' + result4 +
  '\n' + result5 + '\n' + result6);
