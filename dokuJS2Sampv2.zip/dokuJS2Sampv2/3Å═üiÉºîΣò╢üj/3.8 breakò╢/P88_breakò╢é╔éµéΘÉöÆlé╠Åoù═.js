for (i = 0; i < 100; i++) {
  document.write(i, '<br/>');
  if (i == 10) {
    break;
  }
}
